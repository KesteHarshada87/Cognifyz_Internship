package cognifyz_L2_T4;

import java.util.Scanner;

public class PasswordStrength {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		StringBuilder password=new StringBuilder();
		System.out.println("Enter password: ");
		String getPassword=sc.nextLine();
		
		password.append(getPassword);
		
		int UC=0;
		int LC=0;
		int digit=0;
		int SC=0;
		
		if(password.length()>=8) {
			for(int i=0;i<password.length();i++) {
				char c=password.charAt(i);
				if(Character.isUpperCase(c)) {
					UC++;
				}
				else if(Character.isLowerCase(c)) {
					LC++;
				}
				else if(Character.isDigit(c)) {
					digit++;
				}
				else if(!Character.isLetterOrDigit(c)) {
					SC++;
				}
			}
			
			if(UC>=1 && LC>=4 && digit>=2 && SC>=1) {
				System.out.println("Password strength is strong");
			}
				
		}
		
		
		UC=0; LC=0; digit=0; SC=0;
		if(password.length()<8 && password.length()>=6) {
			for(int i=0;i<password.length();i++) {
				char c=password.charAt(i);
				if(Character.isUpperCase(c)) {
					UC++;
				}
				else if(Character.isLowerCase(c)) {
					LC++;
				}
				else if(Character.isDigit(c)) {
					digit++;
				}
				else if(!Character.isLetterOrDigit(c)) {
					SC++;
				}
			}
			
			if(UC>=1 && LC>=3 && digit>=1 && SC>=1) {
				System.out.println("Password strength is medium");
			}
		}
		
		if( password.length()<5  || UC<1 || LC<2 || digit<1 || SC<1) {
			System.out.println("Password strength is weak");
		}
	}

}
