package cognifyz_L1_T4;

import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.Random;

public class PasswordGenerator {

    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int length=0;
        boolean includeNumbers=false;
        boolean includeLower=false;
        boolean includeUpper=false;
        boolean includeSpecial=false;

        try {
            System.out.print("Enter desired length of password: ");
            length=sc.nextInt();

            if(length<1) {
                System.out.println("Password length must be at least 1.");
                return;
            }

            System.out.print("Include numbers? (1 for Yes, 0 for No): ");
            includeNumbers=sc.nextInt()==1;

            System.out.print("Include lowercase letters? (1 for Yes, 0 for No): ");
            includeLower=sc.nextInt()==1;

            System.out.print("Include uppercase letters? (1 for Yes, 0 for No): ");
            includeUpper=sc.nextInt()==1;

            System.out.print("Include special characters? (1 for Yes, 0 for No): ");
            includeSpecial=sc.nextInt()==1;

        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter numbers only.");
            return;
        }

        if (!includeNumbers && !includeLower && !includeUpper && !includeSpecial) {
            System.out.println("You must select at least one character type!");
            return;
        }

        String numbers="0123456789";
        String lowerCaseLetters="abcdefghijklmnopqrstuvwxyz";
        String upperCaseLetters="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String specialCharacters="!@#$%^&*()-_=+[]{}|;:,.<>?";

        StringBuilder characterPool=new StringBuilder();

        if (includeNumbers) characterPool.append(numbers);
        if (includeLower) characterPool.append(lowerCaseLetters);
        if (includeUpper) characterPool.append(upperCaseLetters);
        if (includeSpecial) characterPool.append(specialCharacters);

        StringBuilder password=new StringBuilder();
        Random random=new Random();

        for (int i=0; i<length; i++) {
            int index=random.nextInt(characterPool.length());
            password.append(characterPool.charAt(index));
        }

        System.out.println("Generated password: "+password.toString());
    }
}
