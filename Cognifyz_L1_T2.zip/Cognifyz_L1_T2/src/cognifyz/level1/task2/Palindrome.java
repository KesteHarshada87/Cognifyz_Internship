package cognifyz.level1.task2;

import java.util.Scanner;

public class Palindrome {

	public static void main(String[] args) {
		System.out.println("Enter word or phrase: ");
		Scanner sc=new Scanner(System.in);
		String word=sc.nextLine();
		
		String clean=word.replaceAll("[^a-zA-Z]","").toLowerCase();
		
		char[] newWord=new char[clean.length()];
		int j=clean.length()-1;
		for(int i=0;i<clean.length();i++) {
			newWord[j]=clean.charAt(i);
			j--;
		}
		
		String reverse=new String(newWord);
		if(clean.equals(reverse)) {
			System.out.println("It is palindrome...");
		}
		else {
			System.out.println("It is not palindrome...");
		}
	}

}
