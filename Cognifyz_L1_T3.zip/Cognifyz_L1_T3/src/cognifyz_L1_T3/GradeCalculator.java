package cognifyz_L1_T3;

import java.io.IOException;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class GradeCalculator {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int num=0;
		
		try {
		System.out.println("How many grades you want to enter:");
		num=sc.nextInt();
		
		}catch(InputMismatchException e) {
			System.out.println("Enter valid input...");
		}
		
		String character;
		System.out.println("Enter Grades: ");
		ArrayList<String> grades=new ArrayList<>();
		for(int i=0;i<num;i++) {
			character=sc.nextLine().toUpperCase();
			if(character.length()==1) {
			grades.add(character);
			}
			else {
				i--;
			}
		}
		
		
		int sum=0;
		for(String grade:grades) {
			sum=sum + (int)grade.charAt(0);
		}
		
		int avg=sum/num;
		
		char avgChar=(char) Math.round(avg);
        System.out.println("Average Grade: "+avgChar);
		
	}

}
