package cognifyz_L3_T3;

import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class Calculator {
	
	static JFrame jframe;
	
	public static void main(String[] args) {
		jframe=new JFrame("Calculator");
		jframe.setSize(800, 600);
		jframe.setVisible(true);
		jframe.setDefaultCloseOperation(jframe.EXIT_ON_CLOSE);
		jframe.setLayout(null);
		
		JLabel l1=new JLabel("Number_1");
		l1.setBounds(100, 100, 80, 30);
		jframe.add(l1);
		
		JTextField t1=new JTextField(20);
		t1.setBounds(200, 100, 120, 30);
		jframe.add(t1);
		jframe.revalidate();
		jframe.repaint();
		
		JLabel l2=new JLabel("Number_2");
		l2.setBounds(100,170,80,30);
		jframe.add(l2);
		
		JTextField t2=new JTextField(20);
		t2.setBounds(200, 170, 120, 30);
		jframe.add(t2);
		jframe.revalidate();
		jframe.repaint();
		
		JButton b1=new JButton("Add");
		b1.setBounds(100, 230, 100, 30);
		jframe.add(b1);
		jframe.revalidate();
		jframe.repaint();
		
		JButton b2=new JButton("SUBTRACT");
		b2.setBounds(200, 230, 100, 30);
		jframe.add(b2);
		jframe.revalidate();
		jframe.repaint();
		
		JButton b3=new JButton("DIVISION");
		b3.setBounds(300, 230, 100, 30);
		jframe.add(b3);
		jframe.revalidate();
		jframe.repaint();
		
		JButton b4=new JButton("MULTIPLY");
		b4.setBounds(400, 230, 100, 30);
		jframe.add(b4);
		jframe.revalidate();
		jframe.repaint();
		
		JButton b5=new JButton("MODULUS");
		b5.setBounds(500, 230, 100, 30);
		jframe.add(b5);
		jframe.revalidate();
		jframe.repaint();
		
		b5.addActionListener(e->mudulus(t1,t2));
		b4.addActionListener(e->multiply(t1,t2));
		b3.addActionListener(e->division(t1,t2));
		b2.addActionListener(e->subtract(t1,t2));
		b1.addActionListener(e->add(t1,t2));
		jframe.setVisible(true);
	}

	private static void mudulus(JTextField t1,JTextField t2) {
		try {
			int num1=Integer.parseInt(t1.getText());
			int num2=Integer.parseInt(t2.getText());
			int result=num1%num2;
			
			JLabel l8=new JLabel("Result: "+result);
			l8.setBounds(500, 270, 100, 30);
			jframe.add(l8);
			jframe.revalidate();
			jframe.repaint();
			}
			catch(NumberFormatException n) {
			JLabel l5=new JLabel("Enter valid input");
			l5.setBounds(300,230,100,30);
			jframe.add(l5);
			jframe.revalidate();
			jframe.repaint();
			}
	}

	private static void multiply(JTextField t1, JTextField t2) {
		try {
			int num1=Integer.parseInt(t1.getText());
			int num2=Integer.parseInt(t2.getText());
			int result=num1*num2;
			
			JLabel l8=new JLabel("Result: "+result);
			l8.setBounds(400, 270, 100, 30);
			jframe.add(l8);
			jframe.revalidate();
			jframe.repaint();
			}
			catch(NumberFormatException n) {
			JLabel l5=new JLabel("Enter valid input");
			l5.setBounds(300,230,100,30);
			jframe.add(l5);
			jframe.revalidate();
			jframe.repaint();
			}
	}

	private static void division(JTextField t1, JTextField t2) {
		try {
		int num1=Integer.parseInt(t1.getText());
		int num2=Integer.parseInt(t2.getText());
		int result=num1/num2;
		
		JLabel l7=new JLabel("Result: "+result);
		l7.setBounds(300, 270, 100, 30);
		jframe.add(l7);
		jframe.revalidate();
		jframe.repaint();
		}
		catch(NumberFormatException n) {
		JLabel l5=new JLabel("Enter valid input");
		l5.setBounds(300,230,100,30);
		jframe.add(l5);
		jframe.revalidate();
		jframe.repaint();
		}
	}

	private static void subtract(JTextField t1, JTextField t2) {
		try {
			int num1=Integer.parseInt(t1.getText());
			int num2=Integer.parseInt(t2.getText());
			int result=num1-num2;
			
			JLabel l6=new JLabel("Result: "+result);
			l6.setBounds(210, 270, 100, 30);
			jframe.add(l6);
			jframe.revalidate();
			jframe.repaint();
			
		}catch(NumberFormatException n) {
			JLabel l5=new JLabel("Enter valid input");
			l5.setBounds(300,230,100,30);
			jframe.add(l5);
			jframe.revalidate();
			jframe.repaint();
		}
	}

	private static void add(JTextField t1, JTextField t2) {
		try {
		int num1=Integer.parseInt(t1.getText());
		int num2=Integer.parseInt(t2.getText());
		int result=num1+num2;
		
		JLabel l3=new JLabel("Result: "+result);
		l3.setBounds(110, 270, 100, 30);
		jframe.add(l3);
		jframe.revalidate();
		jframe.repaint();
		
		
		}
		catch(NumberFormatException n) {
			JLabel l4=new JLabel("Enter valid input");
			l4.setBounds(150, 275, 100, 30);
			jframe.add(l4);
			jframe.revalidate();
			jframe.repaint();
		}
	}


}