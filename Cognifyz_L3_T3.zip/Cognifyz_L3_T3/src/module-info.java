/**
 * 
 */
/**
 * 
 */
module Cognifyz_L3_T3 {
	requires java.desktop;
}