package cognifyz_L3_T4;

import javax.swing.*;

public class CurrencyConverter {
    public static void main(String[] args) {
        new Currency();
    }
}

class Currency extends JFrame {
    JLabel l;
    JButton startButton;
    JTextField tfFromCurrency, tfAmount, tfToCurrency;
    JLabel resultLabel;

    public Currency() {
        setTitle("Currency Converter");
        setSize(650, 600);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);

        l = new JLabel("-------------------------------- Currency Converter --------------------------------");
        l.setBounds(100, 30, 400, 30);
        add(l);

        startButton=new JButton("START");
        startButton.setBounds(235, 70, 100, 30);
        add(startButton);

        startButton.addActionListener(e->getCurrency());
    }

    public void getCurrency() {
        startButton.setEnabled(false);

        JLabel fromLabel=new JLabel("From (USD, INR, EUR):");
        fromLabel.setBounds(100, 130, 200, 25);
        add(fromLabel);

        tfFromCurrency=new JTextField();
        tfFromCurrency.setBounds(300, 130, 100, 25);
        add(tfFromCurrency);

        JLabel amountLabel=new JLabel("Enter amount:");
        amountLabel.setBounds(100, 170, 200, 25);
        add(amountLabel);

        tfAmount=new JTextField();
        tfAmount.setBounds(300, 170, 100, 25);
        add(tfAmount);

        JLabel toLabel=new JLabel("To (USD, INR, EUR):");
        toLabel.setBounds(100, 210, 200, 25);
        add(toLabel);

        tfToCurrency=new JTextField();
        tfToCurrency.setBounds(300, 210, 100, 25);
        add(tfToCurrency);

        JButton convertButton=new JButton("Convert");
        convertButton.setBounds(230, 250, 100, 30);
        add(convertButton);

        resultLabel=new JLabel("");
        resultLabel.setBounds(185, 280, 400, 30);
        add(resultLabel);

        convertButton.addActionListener(e->{
            try {
                double value=Double.parseDouble(tfAmount.getText().trim());
                converter();
            } catch (NumberFormatException ex) {
                resultLabel.setText("Invalid amount entered.");
            }
        });

        revalidate();
        repaint();
    }

    public void converter() {
        String from=tfFromCurrency.getText().trim().toUpperCase();
        String to=tfToCurrency.getText().trim().toUpperCase();
        double amount;

        try {
            amount=Double.parseDouble(tfAmount.getText().trim());
        } catch(NumberFormatException e){
            resultLabel.setText("Invalid number format.");
            return;
        }

        double result=0;
        boolean valid=true;

        switch(from){
            case "USD":
                if(to.equals("INR")) result=amount * 83;
                else if(to.equals("EUR")) result=amount * 0.91;
                else if(to.equals("USD")) result=amount;
                else valid=false;
                break;
            case "INR":
                if(to.equals("USD")) result=amount / 83;
                else if(to.equals("EUR")) result=amount / 91;
                else if(to.equals("INR")) result=amount;
                else valid=false;
                break;
            case "EUR":
                if(to.equals("INR")) result=amount * 91;
                else if(to.equals("USD")) result=amount / 0.91;
                else if(to.equals("EUR")) result=amount;
                else valid=false;
                break;
            default:
                valid=false;
        }

        if(!valid){
            resultLabel.setText("Invalid currency codes.");
        } else {
            resultLabel.setText("Result: " + result);
        }

        revalidate();
        repaint();
    }
}
