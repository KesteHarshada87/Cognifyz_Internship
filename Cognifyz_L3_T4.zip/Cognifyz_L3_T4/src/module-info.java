/**
 * 
 */
/**
 * 
 */
module Cognifyz_L3_T4 {
	requires java.desktop;
}