package cognifyz.level1.task1;

import java.util.InputMismatchException;
import java.util.Scanner;

class Converter{
	public Converter() {
	System.out.println("Enter temperature unit (celsius/fahernheit): ");
	Scanner sc=new Scanner(System.in);
	String unit=sc.next();
	
	
	if (unit.equalsIgnoreCase("celsius")) {
		  System.out.println("Enter temperature value: ");
		  try {
		    int value=sc.nextInt();
		    sc.nextLine();  
		    double f=value* 9.0/5 + 32;
		    System.out.printf("%d°C = %.2f°F%n", value, f);

		  } catch (InputMismatchException e) {
		    System.out.println("Invalid input!!");
		    sc.nextLine(); 
		  }
		}
	
	else if(unit.equalsIgnoreCase("Fahrenheit")) {
		System.out.println("Enter tenperature value: ");
		try {
			int value = sc.nextInt();
			sc.nextLine();
			double c=(value-32) * 5/9;
			System.out.printf("%d°F = %.2f°C%n", value, c);
		}catch(InputMismatchException e) {
			System.out.println("Invalid input!!");
		}
	}
	
	else {
		System.out.println("Enter either celcius or fahrenheit...");
	}
}
}

public class TemperatureConverter {

	public static void main(String[] args) {
		System.out.println("----------Temperature Converter---------");
		System.out.println();
		
		Converter converter=new Converter();

	}

}
